import { routeProgressPin } from "./assets";
import { svgDataUri } from "./points";
import type { LatLng, MapLabHandle, MapLabTooltipSource } from "./types";

/**
 * 线组件。路线主体用 OverlayView 绘制 SVG（不是 Advanced Marker），
 * 这样宽度、白色描边、箭头间距都按屏幕像素计算，缩放时视觉稳定。
 *
 * - normal：无箭头路线（Normal route / No arrow）
 * - directional：带方向箭头（Normal route / Has arrow）
 * - progress：已完成段 + 剩余段 + 进度点（Route with progress）
 * 起终点请用 addRoute 的 endpoints 参数，组件包会用点组件拼出
 * Route with normal location / Route with informated location。
 */
export type RouteKind = "normal" | "directional" | "progress";
export type RouteColor = "route1" | "route2" | "route3";
export type RouteState = "default" | "disabled" | "completed";

export interface RouteOptions {
  id?: string;
  path: LatLng[];
  kind?: RouteKind;
  /** 多条路线对比时用 route1 / route2 / route3 区分，默认 route1。 */
  color?: RouteColor;
  state?: RouteState;
  /** kind = "progress" 时的完成比例 0–1。 */
  progress?: number;
  /** 起终点：normal = Normal 点；informated = 信息点（仓库等）；none = 不画。默认 none。 */
  endpoints?: "none" | "normal" | "informated";
  endpointLabels?: [start: string, end: string];
  label: string;
  /** 悬停路线时显示的 Tooltip。 */
  tooltip?: MapLabTooltipSource;
  /** 点击进度点时显示的 Tooltip（司机 / 车辆信息）。 */
  progressTooltip?: MapLabTooltipSource;
  onClick?: (handle: RouteHandle) => void;
  onHoverChange?: (hovered: boolean, handle: RouteHandle) => void;
}

export interface RouteHandle extends MapLabHandle {
  readonly options: RouteOptions;
  setSelected(selected: boolean): void;
  setDimmed(dimmed: boolean): void;
  setProgress(progress: number): void;
  setState(state: RouteState): void;
  /** 进度点当前的经纬度（kind = "progress"）。 */
  progressPosition(): LatLng | null;
}

const PALETTE: Record<RouteColor, { color: string; focused: string; arrow: string }> = {
  route1: { color: "#2A3EF4", focused: "#2232C3", arrow: "#768BFF" },
  route2: { color: "#009995", focused: "#017B77", arrow: "#9EE1DD" },
  route3: { color: "#9583FF", focused: "#8575FF", arrow: "#D9D0F7" },
};
const STATE_COLORS: Record<Exclude<RouteState, "default">, { color: string; arrow: string }> = {
  disabled: { color: "#C9D2FC", arrow: "#D9E0FD" },
  completed: { color: "#9C9EAD", arrow: "#C4C5CE" },
};
const COMPLETED_SEGMENT = { color: "#9C9EAD", arrow: "#C4C5CE" };
const ARROW_PATH = "M1.06065 10.8591L9.79846 2.12132L18.5363 10.8591";
const ARROW_ANCHOR = { x: 9.79846, y: 2.12132 };
const ARROW_SCALE = { default: 7.83 / 20, focused: 12.36 / 20 };
const ARROW_START = 22;
const ARROW_SPACING = 28;

type Pt = { x: number; y: number };

function pathD(points: Pt[]) {
  return points.map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
}

export function splitAtRatio<T extends Pt>(points: T[], ratio: number): { completed: Pt[]; remaining: Pt[] } {
  const r = Math.min(1, Math.max(0, ratio));
  if (points.length < 2) return { completed: points.slice(0, 1), remaining: points.slice(0, 1) };
  const total = points.slice(1).reduce((s, p, i) => s + Math.hypot(p.x - points[i].x, p.y - points[i].y), 0);
  const target = total * r;
  const completed: Pt[] = [points[0]];
  let travelled = 0;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    if (!len) continue;
    if (travelled + len >= target) {
      const t = (target - travelled) / len;
      const split = { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
      completed.push(split);
      return { completed, remaining: [split, ...points.slice(i)] };
    }
    completed.push(b);
    travelled += len;
  }
  return { completed: points, remaining: [points[points.length - 1]] };
}

function arrows(points: Pt[], scale: number, color: string) {
  const out: string[] = [];
  let travelled = 0;
  let next = ARROW_START;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const len = Math.hypot(dx, dy);
    if (!len) continue;
    while (next <= travelled + len) {
      const t = (next - travelled) / len;
      const rot = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
      out.push(
        `<path d="${ARROW_PATH}" fill="none" stroke="${color}" stroke-width="3" transform="translate(${(a.x + dx * t).toFixed(1)} ${(a.y + dy * t).toFixed(1)}) rotate(${rot.toFixed(1)}) scale(${scale}) translate(-${ARROW_ANCHOR.x} -${ARROW_ANCHOR.y})" />`,
      );
      next += ARROW_SPACING;
    }
    travelled += len;
  }
  return out.join("");
}

let uid = 0;

export interface RouteContext {
  map: google.maps.Map;
  onSelect(handle: RouteHandle | null): void;
  showTooltip(position: LatLng, source: MapLabTooltipSource, offsetPx: number): void;
  hideTooltip(): void;
}

export function createRoute(ctx: RouteContext, options: RouteOptions): RouteHandle {
  const id = options.id ?? `maplab-route-${++uid}`;
  const kind = options.kind ?? "directional";
  let state: RouteState = options.state ?? "default";
  let progress = options.progress ?? 0;
  let selected = false;
  let hovered = false;
  let dimmed = false;
  let progressPoint: Pt | null = null;
  let handleRef: RouteHandle;

  class RouteOverlay extends google.maps.OverlayView {
    container = document.createElement("div");
    svgLayer = document.createElement("div");
    pin = document.createElement("span");
    pinButton = document.createElement("button");

    constructor() {
      super();
      this.container.className = "MapLabRoute";
      this.container.dataset.maplabComponent = "route";
      this.container.dataset.maplabKind = kind;
      this.container.dataset.maplabId = id;
      this.container.setAttribute("aria-label", options.label);
      this.svgLayer.className = "MapLabRoute__svg";
      this.pin.className = "MapLabRoute__progress";
      this.pin.innerHTML = `<span class="MapLabRoute__pulse" aria-hidden="true"></span>`;
      this.pinButton.type = "button";
      this.pinButton.className = "MapLabRoute__progressButton";
      this.pinButton.dataset.maplabComponent = "progress-location";
      this.pinButton.setAttribute("aria-label", `${options.label} · 当前位置`);
      this.pinButton.innerHTML = `<img alt="" src="${svgDataUri(routeProgressPin)}" />`;
      this.pinButton.addEventListener("click", this.onPinClick);
      google.maps.OverlayView.preventMapHitsAndGesturesFrom(this.pinButton);
      this.pin.append(this.pinButton);
      this.container.append(this.svgLayer, this.pin);
    }

    onPinClick = (event: MouseEvent) => {
      event.stopPropagation();
      const pos = handleRef.progressPosition();
      if (pos && options.progressTooltip) ctx.showTooltip(pos, options.progressTooltip, 38);
      if (!selected) ctx.onSelect(handleRef);
      options.onClick?.(handleRef);
    };

    hit(event: MouseEvent) {
      return document
        .elementsFromPoint(event.clientX, event.clientY)
        .some((el) => this.container.contains(el) && (el as Element).classList.contains("MapLabRoute__hit"));
    }

    onMove = (event: PointerEvent) => {
      const isHit = this.hit(event);
      if (isHit && !hovered) {
        hovered = true;
        this.draw();
        options.onHoverChange?.(true, handleRef);
      } else if (!isHit && hovered) {
        hovered = false;
        this.draw();
        options.onHoverChange?.(false, handleRef);
        if (options.tooltip && !selected) ctx.hideTooltip();
      }
      if (isHit && options.tooltip) {
        const projection = this.getProjection();
        const rect = this.getMap() ? (this.getMap() as google.maps.Map).getDiv().getBoundingClientRect() : null;
        if (projection && rect) {
          const ll = projection.fromContainerPixelToLatLng(new google.maps.Point(event.clientX - rect.left, event.clientY - rect.top));
          if (ll) ctx.showTooltip(ll.toJSON(), options.tooltip, 14);
        }
      }
    };

    onClick = (event: MouseEvent) => {
      if (!this.hit(event)) return;
      ctx.onSelect(selected ? null : handleRef);
      options.onClick?.(handleRef);
    };

    onAdd() {
      this.getPanes()?.overlayMouseTarget.appendChild(this.container);
      document.addEventListener("pointermove", this.onMove);
      document.addEventListener("click", this.onClick);
    }

    onRemove() {
      document.removeEventListener("pointermove", this.onMove);
      document.removeEventListener("click", this.onClick);
      this.pinButton.removeEventListener("click", this.onPinClick);
      this.container.remove();
    }

    draw() {
      const projection = this.getProjection();
      if (!projection || options.path.length < 2) return;
      const focused = hovered || selected;
      const px = options.path.map((p) => projection.fromLatLngToDivPixel(p) as google.maps.Point);
      const pad = focused ? 30 : 24;
      const minX = Math.min(...px.map((p) => p.x)) - pad;
      const minY = Math.min(...px.map((p) => p.y)) - pad;
      const width = Math.max(1, Math.max(...px.map((p) => p.x)) + pad - minX);
      const height = Math.max(1, Math.max(...px.map((p) => p.y)) + pad - minY);
      const local = px.map((p) => ({ x: p.x - minX, y: p.y - minY }));
      const body = focused ? 12 : 8;
      const outline = body + 4;
      const palette = PALETTE[options.color ?? "route1"];
      const color = state === "default" ? (focused ? palette.focused : palette.color) : STATE_COLORS[state].color;
      const arrowColor = state === "default" ? palette.arrow : STATE_COLORS[state].arrow;
      const scale = focused ? ARROW_SCALE.focused : ARROW_SCALE.default;
      const fullD = pathD(local);
      const split = kind === "progress" ? splitAtRatio(local, progress) : null;
      const remainingD = split ? pathD(split.remaining) : fullD;
      const completedD = split && split.completed.length > 1 ? pathD(split.completed) : "";
      const showArrows = kind !== "normal";
      const maskId = `${id}-mask-${focused ? 1 : 0}`;
      progressPoint = split ? split.completed[split.completed.length - 1] : null;

      this.container.style.cssText = `position:absolute;left:${minX}px;top:${minY}px;width:${width}px;height:${height}px;pointer-events:none;z-index:${focused ? 12 : 10};opacity:${dimmed && !focused ? 0.35 : 1};`;
      this.container.dataset.state = selected ? "selected" : hovered ? "hover" : state;
      this.container.classList.toggle("is-focused", focused);
      this.svgLayer.innerHTML = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
<defs><mask id="${maskId}" maskUnits="userSpaceOnUse"><rect width="${width}" height="${height}" fill="black"/><path d="${fullD}" fill="none" stroke="white" stroke-width="${body}" stroke-linecap="round" stroke-linejoin="round"/></mask></defs>
<path d="${fullD}" fill="none" stroke="#FFFFFF" stroke-width="${outline}" stroke-linecap="round" stroke-linejoin="round"/>
${completedD ? `<path d="${completedD}" fill="none" stroke="${COMPLETED_SEGMENT.color}" stroke-width="${body}" stroke-linecap="round" stroke-linejoin="round"/>` : ""}
<path d="${remainingD}" fill="none" stroke="${color}" stroke-width="${body}" stroke-linecap="round" stroke-linejoin="round"/>
<g mask="url(#${maskId})">${showArrows && split ? arrows(split.completed, scale, COMPLETED_SEGMENT.arrow) : ""}${showArrows ? arrows(split ? split.remaining : local, scale, arrowColor) : ""}</g>
<path class="MapLabRoute__hit" d="${fullD}" fill="none" stroke="transparent" stroke-width="${Math.max(outline, 24)}" stroke-linecap="round" stroke-linejoin="round" style="pointer-events:stroke;cursor:pointer"/>
</svg>`;
      if (progressPoint) {
        this.pin.style.display = "grid";
        this.pin.style.left = `${progressPoint.x}px`;
        this.pin.style.top = `${progressPoint.y}px`;
      } else {
        this.pin.style.display = "none";
      }
    }
  }

  const overlay = new RouteOverlay();
  overlay.setMap(ctx.map);

  handleRef = {
    id,
    options,
    setSelected(next) {
      selected = next;
      overlay.draw();
      if (!next && options.tooltip) ctx.hideTooltip();
    },
    setDimmed(next) {
      dimmed = next;
      overlay.draw();
    },
    setProgress(next) {
      progress = next;
      overlay.draw();
    },
    setState(next) {
      state = next;
      overlay.draw();
    },
    progressPosition() {
      const projection = overlay.getProjection();
      if (!projection || !progressPoint) return null;
      const left = parseFloat(overlay.container.style.left) || 0;
      const top = parseFloat(overlay.container.style.top) || 0;
      const ll = projection.fromDivPixelToLatLng(new google.maps.Point(progressPoint.x + left, progressPoint.y + top));
      return ll ? ll.toJSON() : null;
    },
    remove() {
      overlay.setMap(null);
    },
  };
  return handleRef;
}
