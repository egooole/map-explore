/**
 * React 用法（可选）。非 React 项目不要引入这个文件。
 *
 *   const { ref, lab, error } = useMapLab({
 *     apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
 *     mapId: import.meta.env.VITE_GOOGLE_MAP_ID,
 *     center: { lat: 31.23, lng: 121.47 },
 *     zoom: 11,
 *   });
 *   useEffect(() => {
 *     if (!lab) return;
 *     const handles: Array<{ remove(): void }> = [];
 *     lab.addLocation({ kind: "informated", position, label: "上海仓" }).then((h) => handles.push(h));
 *     return () => handles.forEach((h) => h.remove());
 *   }, [lab, data]);
 *   return <div ref={ref} style={{ width: "100%", height: 480 }} />;
 */
import { useEffect, useRef, useState } from "react";
import { createMapLab, createMapLabMap, loadGoogleMaps, type CreateMapOptions, type LoadGoogleMapsOptions, type MapLab } from "./index";

export type UseMapLabOptions = LoadGoogleMapsOptions & CreateMapOptions;

export function useMapLab(options: UseMapLabOptions) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [lab, setLab] = useState<MapLab | null>(null);
  const [error, setError] = useState<Error | null>(null);
  // 地图只在挂载时创建一次；center / zoom 之后的变化请用 lab.map.setCenter / setZoom。
  const initial = useRef(options);

  useEffect(() => {
    let cancelled = false;
    let instance: MapLab | null = null;
    const { apiKey, language, region, version, preview, ...mapOptions } = initial.current;
    loadGoogleMaps({ apiKey, language, region, version, preview })
      .then(() => {
        if (cancelled || !ref.current) return null;
        return createMapLabMap(ref.current, mapOptions);
      })
      .then((map) => {
        if (cancelled || !map) return;
        instance = createMapLab(map);
        setLab(instance);
      })
      .catch((e: unknown) => !cancelled && setError(e instanceof Error ? e : new Error(String(e))));
    return () => {
      cancelled = true;
      instance?.destroy();
      setLab(null);
    };
  }, []);

  return { ref, lab, map: lab?.map ?? null, error };
}
