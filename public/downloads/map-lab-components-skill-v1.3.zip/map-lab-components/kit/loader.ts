/**
 * 加载 Google Maps JavaScript API 并创建地图。
 *
 * 配置来自环境变量（不要把 Key 写进代码）：
 * - API Key：每个人自己的 Google Cloud 项目里开通 Maps JavaScript API 后创建
 * - Map ID：可选。没有时使用 Google 官方测试用的 DEMO_MAP_ID，
 *   组件样式完全正确，只是底图是 Google 默认样式；
 *   想要 Map Lab 底图，按 SKILL.md 的「底图样式」步骤创建自己的 Map ID。
 */
import { installPreviewMaps, isPreviewMode } from "./preview";

export const DEMO_MAP_ID = "DEMO_MAP_ID";
export { isPreviewMode };

export interface LoadGoogleMapsOptions {
  apiKey: string;
  language?: string;
  region?: string;
  /** 默认 weekly。Advanced Marker 的 anchorLeft / anchorTop 需要较新的版本。 */
  version?: string;
  /**
   * 没有 Key 时是否进入预览模式（浅色网格底图 + 完整的 Map Lab 组件），默认 true。
   * 设为 false 时缺 Key 会直接报错。
   */
  preview?: boolean;
}

let loading: Promise<typeof google> | null = null;

export function loadGoogleMaps({ apiKey, language, region, version = "weekly", preview = true }: LoadGoogleMapsOptions): Promise<typeof google> {
  if (typeof window !== "undefined" && (window as unknown as { google?: typeof google }).google?.maps?.importLibrary) {
    return Promise.resolve((window as unknown as { google: typeof google }).google);
  }
  if (loading) return loading;
  if (!apiKey && preview) {
    installPreviewMaps();
    console.info("[Map Lab] 未配置 Google Maps API Key，已进入预览模式：组件样式和交互完整，底图为网格。配置 Key 后自动显示真实地图。");
    return Promise.resolve((window as unknown as { google: typeof google }).google);
  }
  if (!apiKey) {
    return Promise.reject(
      new Error("[Map Lab] 缺少 Google Maps API Key。请在 .env.local 中配置 VITE_GOOGLE_MAPS_API_KEY（或项目约定的变量名）。"),
    );
  }
  loading = new Promise((resolve, reject) => {
    const callback = `__mapLabGoogleMapsReady_${Date.now()}`;
    (window as unknown as Record<string, () => void>)[callback] = () => {
      delete (window as unknown as Record<string, unknown>)[callback];
      resolve((window as unknown as { google: typeof google }).google);
    };
    const params = new URLSearchParams({ key: apiKey, v: version, callback, loading: "async" });
    if (language) params.set("language", language);
    if (region) params.set("region", region);
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?${params.toString()}`;
    script.async = true;
    script.onerror = () => {
      loading = null;
      reject(new Error("[Map Lab] Google Maps 脚本加载失败，请检查网络和 API Key 的域名限制。"));
    };
    document.head.appendChild(script);
  });
  return loading;
}

export interface CreateMapOptions extends Omit<google.maps.MapOptions, "mapId"> {
  /** 不传或为空时使用 DEMO_MAP_ID。 */
  mapId?: string;
}

export async function createMapLabMap(element: HTMLElement, options: CreateMapOptions): Promise<google.maps.Map> {
  const { Map } = (await google.maps.importLibrary("maps")) as google.maps.MapsLibrary;
  const mapId = options.mapId || DEMO_MAP_ID;
  if (mapId === DEMO_MAP_ID && !isPreviewMode()) {
    console.info(
      "[Map Lab] 当前使用 DEMO_MAP_ID：组件样式正确，底图为 Google 默认样式。配置 VITE_GOOGLE_MAP_ID 可切换到 Map Lab 底图。",
    );
  }
  return new Map(element, {
    clickableIcons: false,
    disableDefaultUI: true,
    zoomControl: true,
    gestureHandling: "greedy",
    ...options,
    mapId,
  });
}
