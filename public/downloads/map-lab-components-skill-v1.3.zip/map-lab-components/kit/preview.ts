/**
 * 预览模式：没有 Google Maps API Key 时，用一个轻量的替身地图渲染 Map Lab 组件。
 *
 * - 只实现组件包用到的那部分 google.maps 接口（Map / OverlayView / Data / AdvancedMarkerElement 等）。
 * - 浅色网格背景，支持拖拽平移、滚轮缩放；没有真实底图、道路和地名。
 * - 组件的样式和交互与真实地图一致，方便没有 Key 的人先看效果。
 * - 配置 Key 后 loadGoogleMaps 会加载真正的 Google Maps，这个文件不会被用到。
 *
 * 不要在业务代码里直接调用这里的类。
 */

type LatLngLike = google.maps.LatLngLiteral | { lat(): number; lng(): number };
type Listener = (...args: any[]) => void;

const TILE = 256;
const lit = (p: LatLngLike): google.maps.LatLngLiteral =>
  typeof (p as { lat: unknown }).lat === "function"
    ? { lat: (p as { lat(): number }).lat(), lng: (p as { lng(): number }).lng() }
    : (p as google.maps.LatLngLiteral);

class Emitter {
  private handlers: Record<string, Listener[]> = {};
  addListener(name: string, fn: Listener) {
    (this.handlers[name] ??= []).push(fn);
    return { remove: () => (this.handlers[name] = (this.handlers[name] ?? []).filter((f) => f !== fn)) };
  }
  emit(name: string, ...args: unknown[]) {
    (this.handlers[name] ?? []).slice().forEach((fn) => fn(...args));
  }
}

class PLatLng {
  constructor(private a: number, private b: number) {}
  lat() { return this.a; }
  lng() { return this.b; }
  toJSON() { return { lat: this.a, lng: this.b }; }
}

class PPoint {
  constructor(public x: number, public y: number) {}
}

class PLatLngBounds {
  s = 90; n = -90; w = 180; e = -180;
  extend(p: LatLngLike) {
    const { lat, lng } = lit(p);
    this.s = Math.min(this.s, lat); this.n = Math.max(this.n, lat);
    this.w = Math.min(this.w, lng); this.e = Math.max(this.e, lng);
    return this;
  }
  union(b: PLatLngBounds) {
    if (b.s <= b.n) { this.extend({ lat: b.s, lng: b.w }); this.extend({ lat: b.n, lng: b.e }); }
    return this;
  }
  isEmpty() { return this.s > this.n; }
  getCenter() { return new PLatLng((this.s + this.n) / 2, (this.w + this.e) / 2); }
}

function worldPx(p: google.maps.LatLngLiteral, zoom: number) {
  const size = TILE * 2 ** zoom;
  const sin = Math.min(Math.max(Math.sin((p.lat * Math.PI) / 180), -0.9999), 0.9999);
  return { x: ((p.lng + 180) / 360) * size, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * size };
}
function fromWorldPx(x: number, y: number, zoom: number) {
  const size = TILE * 2 ** zoom;
  const lng = (x / size) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / size;
  return { lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lng };
}

const STYLE_ID = "maplab-preview-style";
function injectStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
.MapLabPreview{position:relative;overflow:hidden;background-color:#f3f4f7;cursor:grab;touch-action:none;user-select:none;font-family:-apple-system,"SF Pro Text","PingFang SC","Segoe UI",Roboto,sans-serif}
.MapLabPreview.is-dragging{cursor:grabbing}
.MapLabPreview__grid{position:absolute;inset:0;pointer-events:none;background-image:linear-gradient(#e3e6ee 1px,transparent 1px),linear-gradient(90deg,#e3e6ee 1px,transparent 1px)}
.MapLabPreview__pane{position:absolute;left:0;top:0;width:0;height:0}
.MapLabPreview__data{position:absolute;left:0;top:0;overflow:visible;pointer-events:none}
.MapLabPreview__data path{pointer-events:visiblePainted}
.MapLabPreview__marker{position:absolute;left:0;top:0}
.MapLabPreview__badge{position:absolute;left:12px;bottom:12px;z-index:5;display:flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;background:rgb(255 255 255 / 92%);box-shadow:0 2px 8px rgb(15 23 42 / 10%);color:#4c5476;font-size:12px;line-height:18px;pointer-events:none}
.MapLabPreview__badge::before{content:"";width:6px;height:6px;border-radius:50%;background:#e8771a}
.MapLabPreview__zoom{position:absolute;right:12px;bottom:12px;z-index:5;display:flex;flex-direction:column;border-radius:6px;overflow:hidden;box-shadow:0 2px 8px rgb(15 23 42 / 12%)}
.MapLabPreview__zoom button{width:32px;height:32px;border:0;background:#fff;color:#171718;font-size:18px;line-height:1;cursor:pointer}
.MapLabPreview__zoom button+button{border-top:1px solid #edeeef}`;
  document.head.appendChild(style);
}

class PMap extends Emitter {
  center: google.maps.LatLngLiteral;
  zoom: number;
  readonly root: HTMLElement;
  readonly grid = document.createElement("div");
  readonly panes: Record<"overlayLayer" | "markerLayer" | "overlayMouseTarget" | "floatPane", HTMLDivElement>;
  readonly views = new Set<{ redraw(): void }>();

  constructor(private element: HTMLElement, options: google.maps.MapOptions = {}) {
    super();
    injectStyle();
    this.center = options.center ? lit(options.center as LatLngLike) : { lat: 31.23, lng: 121.47 };
    this.zoom = options.zoom ?? 11;
    element.innerHTML = "";
    this.root = document.createElement("div");
    this.root.className = "MapLabPreview";
    this.root.style.cssText = "position:absolute;inset:0";
    if (getComputedStyle(element).position === "static") element.style.position = "relative";
    this.grid.className = "MapLabPreview__grid";
    this.root.appendChild(this.grid);
    const mk = (z: number) => {
      const pane = document.createElement("div");
      pane.className = "MapLabPreview__pane";
      pane.style.zIndex = String(z);
      this.root.appendChild(pane);
      return pane;
    };
    // 层级：区域 < 路线 < 点 < Tooltip，与 Map Lab 的图层约定一致
    this.panes = { overlayLayer: mk(1), overlayMouseTarget: mk(2), markerLayer: mk(3), floatPane: mk(4) };
    const badge = document.createElement("div");
    badge.className = "MapLabPreview__badge";
    badge.textContent = "预览模式 · 配置 Google Maps Key 后显示真实底图";
    this.root.appendChild(badge);
    if (options.zoomControl !== false) {
      const zoom = document.createElement("div");
      zoom.className = "MapLabPreview__zoom";
      zoom.innerHTML = `<button type="button" aria-label="放大">+</button><button type="button" aria-label="缩小">−</button>`;
      const [plus, minus] = zoom.querySelectorAll("button");
      plus.addEventListener("click", (e) => { e.stopPropagation(); this.setZoom(this.zoom + 1); });
      minus.addEventListener("click", (e) => { e.stopPropagation(); this.setZoom(this.zoom - 1); });
      zoom.addEventListener("pointerdown", (e) => e.stopPropagation());
      this.root.appendChild(zoom);
    }
    element.appendChild(this.root);
    this.bindGestures();
    new ResizeObserver(() => this.render()).observe(element);
    requestAnimationFrame(() => this.render());
  }

  private bindGestures() {
    let drag: { x: number; y: number; moved: boolean; center: { x: number; y: number } } | null = null;
    const isBackground = (t: EventTarget | null) =>
      t === this.root || t === this.grid || (t instanceof Element && t.classList.contains("MapLabPreview__pane"));
    this.root.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const target = e.target as Element;
      if (!isBackground(target) && target.closest("[data-maplab-component], button, .MapLabPreview__data path")) {
        // 在组件上按下时不拖动，避免吞掉点击
        if (!target.closest(".MapLabRoute__svg")) return;
      }
      drag = { x: e.clientX, y: e.clientY, moved: false, center: worldPx(this.center, this.zoom) };
    });
    window.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 4) return;
      drag.moved = true;
      this.root.classList.add("is-dragging");
      this.center = fromWorldPx(drag.center.x - dx, drag.center.y - dy, this.zoom);
      this.render();
    });
    window.addEventListener("pointerup", () => {
      if (drag?.moved) {
        // 拖动结束后吞掉紧随的 click，避免误触发选中 / 取消
        const swallow = (ev: Event) => { ev.stopPropagation(); window.removeEventListener("click", swallow, true); };
        window.addEventListener("click", swallow, true);
        setTimeout(() => window.removeEventListener("click", swallow, true), 0);
        this.emit("idle");
      }
      drag = null;
      this.root.classList.remove("is-dragging");
    });
    this.root.addEventListener("click", (e) => {
      if (isBackground(e.target)) this.emit("click", { latLng: null });
    });
    this.root.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const rect = this.root.getBoundingClientRect();
        this.zoomAround(this.zoom + (e.deltaY < 0 ? 0.5 : -0.5), e.clientX - rect.left, e.clientY - rect.top);
      },
      { passive: false },
    );
  }

  private zoomAround(next: number, px: number, py: number) {
    next = Math.max(2, Math.min(20, next));
    const anchor = this.toLatLng(px, py);
    this.zoom = next;
    const w = worldPx(anchor, next);
    const { width, height } = this.size();
    this.center = fromWorldPx(w.x - px + width / 2, w.y - py + height / 2, next);
    this.render();
    this.emit("zoom_changed");
    this.emit("idle");
  }

  size() {
    return { width: this.root.clientWidth || this.element.clientWidth, height: this.root.clientHeight || this.element.clientHeight };
  }
  toPixel(p: LatLngLike) {
    const c = worldPx(this.center, this.zoom);
    const w = worldPx(lit(p), this.zoom);
    const { width, height } = this.size();
    return new PPoint(w.x - c.x + width / 2, w.y - c.y + height / 2);
  }
  toLatLng(x: number, y: number) {
    const c = worldPx(this.center, this.zoom);
    const { width, height } = this.size();
    return fromWorldPx(c.x + x - width / 2, c.y + y - height / 2, this.zoom);
  }

  render() {
    const c = worldPx(this.center, this.zoom);
    const cell = 64;
    this.grid.style.backgroundSize = `${cell}px ${cell}px`;
    const { width, height } = this.size();
    this.grid.style.backgroundPosition = `${(-c.x + width / 2) % cell}px ${(-c.y + height / 2) % cell}px`;
    this.views.forEach((v) => v.redraw());
    this.emit("bounds_changed");
  }

  getDiv() { return this.element; }
  getZoom() { return this.zoom; }
  getCenter() { return new PLatLng(this.center.lat, this.center.lng); }
  setZoom(z: number) { const { width, height } = this.size(); this.zoomAround(z, width / 2, height / 2); }
  setCenter(p: LatLngLike) { this.center = lit(p); this.render(); this.emit("idle"); }
  panTo(p: LatLngLike) { this.setCenter(p); }
  setOptions() {}
  fitBounds(b: PLatLngBounds, padding?: number | google.maps.Padding) {
    if (b.isEmpty()) return;
    const pad = typeof padding === "number" ? { top: padding, bottom: padding, left: padding, right: padding } : { top: 0, bottom: 0, left: 0, right: 0, ...(padding ?? {}) };
    const { width, height } = this.size();
    const availW = Math.max(40, width - pad.left - pad.right);
    const availH = Math.max(40, height - pad.top - pad.bottom);
    let zoom = 20;
    for (; zoom > 2; zoom -= 0.25) {
      const a = worldPx({ lat: b.n, lng: b.w }, zoom);
      const z = worldPx({ lat: b.s, lng: b.e }, zoom);
      if (z.x - a.x <= availW && z.y - a.y <= availH) break;
    }
    this.zoom = zoom;
    const a = worldPx({ lat: b.n, lng: b.w }, zoom);
    const z = worldPx({ lat: b.s, lng: b.e }, zoom);
    const cx = (a.x + z.x) / 2 + (pad.right - pad.left) / 2;
    const cy = (a.y + z.y) / 2 + (pad.bottom - pad.top) / 2;
    this.center = fromWorldPx(cx, cy, zoom);
    this.render();
    this.emit("idle");
  }
}

class POverlayView extends Emitter {
  private pmap: PMap | null = null;
  private view = { redraw: () => (this as unknown as { draw?: () => void }).draw?.() };
  static preventMapHitsAndGesturesFrom(el: Element) {
    el.addEventListener("pointerdown", (e) => e.stopPropagation());
  }
  setMap(map: PMap | null) {
    if (this.pmap) {
      this.pmap.views.delete(this.view);
      (this as unknown as { onRemove?: () => void }).onRemove?.();
    }
    this.pmap = map;
    if (map) {
      (this as unknown as { onAdd?: () => void }).onAdd?.();
      map.views.add(this.view);
      this.view.redraw();
    }
  }
  getMap() { return this.pmap; }
  getPanes() { return this.pmap?.panes ?? null; }
  getProjection() {
    const m = this.pmap;
    if (!m) return null;
    const toLL = (p: { x: number; y: number }) => { const ll = m.toLatLng(p.x, p.y); return new PLatLng(ll.lat, ll.lng); };
    return {
      fromLatLngToDivPixel: (p: LatLngLike) => m.toPixel(p),
      fromLatLngToContainerPixel: (p: LatLngLike) => m.toPixel(p),
      fromDivPixelToLatLng: toLL,
      fromContainerPixelToLatLng: toLL,
    };
  }
}

class PAdvancedMarkerElement extends Emitter {
  readonly host = document.createElement("div");
  private pmap: PMap | null = null;
  private pos: google.maps.LatLngLiteral | null = null;
  private view = { redraw: () => this.place() };
  anchorLeft = "-50%";
  anchorTop = "-100%";
  gmpClickable = false;
  title = "";

  constructor(options: { content?: HTMLElement; map?: PMap | null; position?: LatLngLike; zIndex?: number | null; title?: string; gmpClickable?: boolean } = {}) {
    super();
    this.host.className = "MapLabPreview__marker";
    if (options.content) this.host.appendChild(options.content);
    this.gmpClickable = Boolean(options.gmpClickable);
    this.title = options.title ?? "";
    this.zIndex = options.zIndex ?? null;
    this.host.addEventListener("click", (e) => {
      if (!this.gmpClickable) return;
      e.stopPropagation();
      this.emit("click", { domEvent: e });
    });
    this.host.addEventListener("pointerdown", (e) => this.gmpClickable && e.stopPropagation());
    if (options.position) this.position = options.position;
    this.map = options.map ?? null;
  }
  set zIndex(z: number | null) { this.host.style.zIndex = z == null ? "" : String(z); }
  get zIndex() { return this.host.style.zIndex ? Number(this.host.style.zIndex) : null; }
  set position(p: LatLngLike | null) { this.pos = p ? lit(p) : null; this.place(); }
  get position() { return this.pos; }
  set map(m: PMap | null) {
    this.pmap?.views.delete(this.view);
    this.host.remove();
    this.pmap = m;
    if (m) { m.panes.markerLayer.appendChild(this.host); m.views.add(this.view); this.place(); }
  }
  get map() { return this.pmap; }
  set content(el: HTMLElement) { this.host.replaceChildren(el); }
  private place() {
    if (!this.pmap || !this.pos) return;
    const p = this.pmap.toPixel(this.pos);
    this.host.style.transform = `translate(${p.x}px, ${p.y}px) translate(${this.anchorLeft}, ${this.anchorTop})`;
  }
}

type Geometry = { type: string; coordinates: any };

class PFeature {
  constructor(private raw: { id?: string | number; properties?: Record<string, unknown>; geometry: Geometry }) {}
  getProperty(k: string) { return this.raw.properties?.[k]; }
  getId() { return this.raw.id; }
  getGeometry() {
    const g = this.raw.geometry;
    return {
      getType: () => g.type,
      forEachLatLng: (cb: (ll: PLatLng) => void) => rings(g).forEach((r) => r.forEach(([lng, lat]) => cb(new PLatLng(lat, lng)))),
    };
  }
  rings() { return rings(this.raw.geometry); }
}

function rings(g: Geometry): number[][][] {
  if (g.type === "Polygon") return g.coordinates;
  if (g.type === "MultiPolygon") return (g.coordinates as number[][][][]).flat();
  return [];
}

class PData extends Emitter {
  private pmap: PMap | null = null;
  private features: PFeature[] = [];
  private paths = new Map<PFeature, SVGPathElement>();
  private style: google.maps.Data.StyleOptions | ((f: PFeature) => google.maps.Data.StyleOptions) = {};
  private svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  private view = { redraw: () => this.draw() };

  constructor(options: { map?: PMap } = {}) {
    super();
    this.svg.setAttribute("class", "MapLabPreview__data");
    if (options.map) this.setMap(options.map);
  }
  setMap(m: PMap | null) {
    this.pmap?.views.delete(this.view);
    this.svg.remove();
    this.pmap = m;
    if (m) { m.panes.overlayLayer.appendChild(this.svg); m.views.add(this.view); this.draw(); }
  }
  getMap() { return this.pmap; }
  addGeoJson(geojson: { type: string; features?: any[] } & Record<string, any>) {
    const list = geojson.type === "FeatureCollection" ? geojson.features ?? [] : [geojson];
    const added = list.map((f) => new PFeature(f));
    added.forEach((f) => {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("fill-rule", "evenodd");
      path.addEventListener("pointerenter", () => this.emit("mouseover", { feature: f }));
      path.addEventListener("pointerleave", () => this.emit("mouseout", { feature: f }));
      path.addEventListener("click", (e) => { e.stopPropagation(); this.emit("click", { feature: f }); });
      this.paths.set(f, path);
      this.svg.appendChild(path);
    });
    this.features.push(...added);
    this.draw();
    return added;
  }
  forEach(cb: (f: PFeature) => void) { this.features.forEach(cb); }
  setStyle(style: PData["style"]) { this.style = style; this.draw(); }
  getStyle() { return this.style; }
  revertStyle() { this.draw(); }
  private draw() {
    const m = this.pmap;
    if (!m) return;
    const { width, height } = m.size();
    this.svg.setAttribute("width", String(width));
    this.svg.setAttribute("height", String(height));
    const ordered: Array<[number, SVGPathElement]> = [];
    this.paths.forEach((path, f) => {
      const s = typeof this.style === "function" ? this.style(f) ?? {} : this.style;
      const d = f.rings().map((r) => r.map(([lng, lat], i) => { const p = m.toPixel({ lat, lng }); return `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`; }).join("") + "Z").join("");
      path.setAttribute("d", d);
      path.setAttribute("fill", s.fillColor ?? "#000");
      path.setAttribute("fill-opacity", String(s.fillOpacity ?? 0.3));
      path.setAttribute("stroke", s.strokeColor ?? "#000");
      path.setAttribute("stroke-opacity", String(s.strokeOpacity ?? 1));
      path.setAttribute("stroke-width", String(s.strokeWeight ?? 1));
      path.setAttribute("stroke-linejoin", "round");
      path.style.cursor = (s as { cursor?: string }).cursor ?? "default";
      path.style.display = s.visible === false ? "none" : "";
      ordered.push([s.zIndex ?? 0, path]);
    });
    ordered.sort((a, b) => a[0] - b[0]).forEach(([, p]) => this.svg.appendChild(p));
  }
}

let installed = false;

/** 安装预览版 google.maps。已有真实 Google Maps 时不做任何事。 */
export function installPreviewMaps() {
  const w = window as unknown as { google?: { maps?: unknown }; __mapLabPreview?: boolean };
  if (w.google?.maps && !w.__mapLabPreview) return false;
  if (installed) return true;
  installed = true;
  w.__mapLabPreview = true;
  const maps = {
    Map: PMap,
    OverlayView: POverlayView,
    Point: PPoint,
    LatLng: PLatLng,
    LatLngBounds: PLatLngBounds,
    Data: PData,
    marker: { AdvancedMarkerElement: PAdvancedMarkerElement },
    event: { addListener: (o: Emitter, n: string, fn: Listener) => o.addListener(n, fn), trigger: (o: Emitter, n: string, ...a: unknown[]) => o.emit(n, ...a) },
    importLibrary: async (name: string) =>
      name === "marker" ? { AdvancedMarkerElement: PAdvancedMarkerElement } : { Map: PMap, OverlayView: POverlayView, LatLngBounds: PLatLngBounds, Data: PData },
  };
  w.google = { ...(w.google ?? {}), maps };
  return true;
}

export function isPreviewMode() {
  return Boolean((window as unknown as { __mapLabPreview?: boolean }).__mapLabPreview);
}
