/**
 * Map Lab 组件包的公共类型。
 * 所有组件都画在调用方已有的 google.maps.Map 实例上，组件包不会自己创建第二个地图。
 */

export type LatLng = google.maps.LatLngLiteral;

/** 组件状态。disabled = 设计稿里的 Disable；completed = 已完成。 */
export type MapLabState = "default" | "disabled" | "completed" | "emphasized" | "selected";

/** Tooltip 里状态标签的语气色。 */
export type MapLabTagTone = "info" | "success" | "neutral" | "warning";

/**
 * Tooltip 内容（对应 Network Map View 设计稿的 Chart tooltip）。
 * rows 为 [标签, 数值]，hint 是底部的灰色说明行。
 */
export interface MapLabTooltipContent {
  title: string;
  tag?: { text: string; tone?: MapLabTagTone };
  rows?: Array<[label: string, value: string | number]>;
  hint?: string;
}

export type MapLabTooltipSource = MapLabTooltipContent | (() => MapLabTooltipContent | null);

/** 所有组件 handle 共有的能力。 */
export interface MapLabHandle {
  readonly id: string;
  remove(): void;
}
