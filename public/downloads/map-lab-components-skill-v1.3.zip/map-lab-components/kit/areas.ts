import type { LatLng, MapLabHandle, MapLabTooltipContent, MapLabTooltipSource } from "./types";

/**
 * 面组件（Area Selection / Multiple Areas / 覆盖状态）。
 * 用 google.maps.Data 渲染真实 GeoJSON，不要用矩形或 bbox 代替行政区。
 *
 * 着色方式二选一：
 * - status：覆盖状态三档（full / partial / none），对应 Fully / Partially / Not covered
 * - color：自定义单色（route1/2/3 或任意 HEX），用于多区域对比
 * 都不传时使用 Map Lab 默认蓝色区域样式。
 */
export type AreaStatus = "full" | "partial" | "none";

export interface AreaStyleInput {
  status?: AreaStatus;
  color?: string;
  disabled?: boolean;
}

export interface AreaOptions {
  id?: string;
  /** GeoJSON FeatureCollection 对象，或可 fetch 的 URL。 */
  geojson: object | string;
  /** 用哪个 feature 属性作为区域 ID，默认 "id"，取不到时用 "name"。 */
  idProperty?: string;
  /** 用哪个属性作为区域名称（Tooltip 标题、无障碍名称），默认 "name"。 */
  nameProperty?: string;
  /** 按区域返回着色方式。 */
  style?: (areaId: string, feature: google.maps.Data.Feature) => AreaStyleInput;
  /** 按区域返回 Tooltip 内容；返回 null 表示该区域不显示。默认 hover 显示。 */
  tooltip?: (areaId: string, feature: google.maps.Data.Feature) => MapLabTooltipContent | null;
  /** 区域是否可点击，默认可点击（status = "none" 或 disabled 的区域不可点击）。 */
  clickable?: (areaId: string, feature: google.maps.Data.Feature) => boolean;
  onClick?: (areaId: string, feature: google.maps.Data.Feature) => void;
  /** 加载后自动缩放到全部区域，默认 true。 */
  fitBounds?: boolean;
}

export interface AreaHandle extends MapLabHandle {
  readonly layer: google.maps.Data;
  /** 选中区域（null 取消）。 */
  select(areaId: string | null): void;
  /** 让除这些 ID 以外的区域变淡（用于「设施覆盖了哪些区」）；传 null 恢复。 */
  focus(areaIds: string[] | null): void;
  /** 高亮描边 1 秒，用于「定位到某区域」。 */
  flash(areaId: string): void;
  /** 缩放到某个区域，长边约占地图 80%。 */
  fitTo(areaId: string): void;
  refresh(): void;
  centerOf(areaId: string): LatLng | null;
}

const STATUS_COLORS: Record<AreaStatus, string> = { full: "#009995", partial: "#2A3EF4", none: "#616B94" };
const PRIMARY = "#2A3EF4";

let uid = 0;

export interface AreaContext {
  map: google.maps.Map;
  showTooltip(position: LatLng, source: MapLabTooltipSource, offsetPx: number): void;
  hideTooltip(): void;
}

function boundsOf(feature: google.maps.Data.Feature) {
  const bounds = new google.maps.LatLngBounds();
  feature.getGeometry()?.forEachLatLng((ll) => bounds.extend(ll));
  return bounds;
}

export async function createAreas(ctx: AreaContext, options: AreaOptions): Promise<AreaHandle> {
  const id = options.id ?? `maplab-areas-${++uid}`;
  const layer = new google.maps.Data({ map: ctx.map });
  const geojson = typeof options.geojson === "string" ? await fetch(options.geojson).then((r) => r.json()) : options.geojson;
  const features = layer.addGeoJson(geojson);
  const idProp = options.idProperty ?? "id";
  const nameProp = options.nameProperty ?? "name";
  const areaId = (f: google.maps.Data.Feature) => String(f.getProperty(idProp) ?? f.getId() ?? f.getProperty("name") ?? "");
  const areaName = (f: google.maps.Data.Feature) => String(f.getProperty(nameProp) ?? areaId(f));
  const byId = new Map(features.map((f) => [areaId(f), f]));

  let hovered: string | null = null;
  let selected: string | null = null;
  let focusSet: Set<string> | null = null;
  let flashId: string | null = null;

  const isClickable = (fid: string, f: google.maps.Data.Feature) => {
    if (options.clickable) return options.clickable(fid, f);
    const s = options.style?.(fid, f);
    return !(s?.status === "none" || s?.disabled);
  };

  layer.setStyle((feature) => {
    const f = feature as google.maps.Data.Feature;
    const fid = areaId(f);
    const s = options.style?.(fid, f) ?? {};
    const active = fid === hovered || fid === selected;
    const outOfFocus = focusSet !== null && !focusSet.has(fid);
    let fillColor = PRIMARY;
    let strokeColor = PRIMARY;
    let fillOpacity = 0.1;
    let strokeWeight = 2;
    let strokeOpacity = 1;
    if (s.status) {
      fillColor = STATUS_COLORS[s.status];
      strokeColor = "#FFFFFF";
      strokeWeight = 1;
      fillOpacity = s.status === "none" ? 0.22 : 0.26;
      if (active) {
        fillOpacity += 0.16;
        strokeColor = "#171718";
        strokeWeight = 2;
      }
    } else if (s.color) {
      fillColor = s.color;
      strokeColor = s.color;
      fillOpacity = active ? 0.4 : 0.1;
    } else if (s.disabled) {
      fillOpacity = 0.06;
      strokeColor = "#C9D2FC";
    } else if (active) {
      fillOpacity = 0.4;
    }
    if (outOfFocus) {
      fillOpacity *= 0.35;
      strokeOpacity = 0.35;
    }
    if (flashId === fid || (focusSet?.has(fid) && focusSet.size < byId.size)) {
      strokeColor = flashId === fid ? PRIMARY : "#171718";
      strokeWeight = flashId === fid ? 4 : 2;
    }
    return {
      fillColor,
      fillOpacity,
      strokeColor,
      strokeOpacity,
      strokeWeight,
      zIndex: active ? 2 : 1,
      cursor: isClickable(fid, f) && options.onClick ? "pointer" : "default",
    } as google.maps.Data.StyleOptions;
  });

  const handle: AreaHandle = {
    id,
    layer,
    select(next) {
      selected = next;
      layer.revertStyle();
      handle.refresh();
    },
    focus(ids) {
      focusSet = ids ? new Set(ids) : null;
      handle.refresh();
    },
    flash(fid) {
      flashId = fid;
      handle.refresh();
      window.setTimeout(() => {
        if (flashId === fid) {
          flashId = null;
          handle.refresh();
        }
      }, 1000);
    },
    fitTo(fid) {
      const f = byId.get(fid);
      if (!f) return;
      const div = ctx.map.getDiv();
      const padX = Math.round(div.clientWidth * 0.1);
      const padY = Math.round(div.clientHeight * 0.1);
      ctx.map.fitBounds(boundsOf(f), { top: padY, bottom: padY, left: padX, right: padX });
    },
    refresh() {
      layer.setStyle(layer.getStyle());
    },
    centerOf(fid) {
      const f = byId.get(fid);
      return f ? boundsOf(f).getCenter().toJSON() : null;
    },
    remove() {
      listeners.forEach((l) => l.remove());
      ctx.hideTooltip();
      layer.setMap(null);
    },
  };

  const listeners = [
    layer.addListener("mouseover", (event: google.maps.Data.MouseEvent) => {
      const fid = areaId(event.feature);
      hovered = fid;
      handle.refresh();
      if (options.tooltip) {
        const content = options.tooltip(fid, event.feature);
        const center = boundsOf(event.feature).getCenter().toJSON();
        if (content) ctx.showTooltip(center, { ...content, title: content.title || areaName(event.feature) }, 6);
      }
    }),
    layer.addListener("mouseout", (event: google.maps.Data.MouseEvent) => {
      if (hovered === areaId(event.feature)) {
        hovered = null;
        handle.refresh();
        ctx.hideTooltip();
      }
    }),
    layer.addListener("click", (event: google.maps.Data.MouseEvent) => {
      const fid = areaId(event.feature);
      if (!isClickable(fid, event.feature)) return;
      options.onClick?.(fid, event.feature);
    }),
  ];

  if (options.fitBounds !== false && features.length) {
    const all = new google.maps.LatLngBounds();
    features.forEach((f) => all.union(boundsOf(f)));
    ctx.map.fitBounds(all, 48);
  }

  return handle;
}
