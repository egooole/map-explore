import type { LatLng, MapLabTooltipContent, MapLabTooltipSource } from "./types";

/**
 * 地图上的 Tooltip（Chart tooltip 规格）。
 * - 同一张地图同一时间只显示一个 Tooltip。
 * - 用 OverlayView 放在 floatPane，地图平移、缩放时跟着锚点走，并始终在路线和点之上。
 * - pointer-events: none，不会挡住下面的点、线、面。
 */
export interface MapLabTooltipController {
  show(position: LatLng, content: MapLabTooltipSource, offsetPx?: number): void;
  hide(): void;
  destroy(): void;
}

export function resolveTooltip(source: MapLabTooltipSource | undefined): MapLabTooltipContent | null {
  if (!source) return null;
  return typeof source === "function" ? source() : source;
}

function escapeHtml(value: string | number) {
  return String(value).replace(/[&<>"']/g, (char) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] as string,
  );
}

export function renderTooltipHtml(content: MapLabTooltipContent) {
  const tag = content.tag
    ? `<span class="MapLabTag MapLabTag--${content.tag.tone ?? "info"}">${escapeHtml(content.tag.text)}</span>`
    : "";
  const rows = (content.rows ?? [])
    .map(([label, value]) => `<div class="MapLabTooltip__row"><span>${escapeHtml(label)}</span><b>${escapeHtml(value)}</b></div>`)
    .join("");
  const hint = content.hint ? `<div class="MapLabTooltip__hint">${escapeHtml(content.hint)}</div>` : "";
  return `<div class="MapLabTooltip__box"><div class="MapLabTooltip__head"><div class="MapLabTooltip__title">${escapeHtml(content.title)}</div>${tag}</div>${rows}${hint}</div><div class="MapLabTooltip__arrow" aria-hidden="true"></div>`;
}

export function createTooltipController(map: google.maps.Map): MapLabTooltipController {
  const element = document.createElement("div");
  element.className = "MapLabTooltip";
  element.setAttribute("role", "tooltip");
  element.dataset.maplabComponent = "tooltip";
  element.style.position = "absolute";
  element.style.transform = "translate(-50%, -100%)";
  let anchor: LatLng | null = null;

  // 放在 floatPane（地图最上层），保证压在路线和点之上。
  class TooltipOverlay extends google.maps.OverlayView {
    onAdd() {
      this.getPanes()?.floatPane.appendChild(element);
    }
    onRemove() {
      element.remove();
    }
    draw() {
      const projection = this.getProjection();
      if (!projection || !anchor) return;
      const px = projection.fromLatLngToDivPixel(anchor);
      if (!px) return;
      element.style.left = `${px.x}px`;
      element.style.top = `${px.y}px`;
    }
  }
  const overlay = new TooltipOverlay();
  overlay.setMap(map);

  return {
    show(position, source, offsetPx = 8) {
      const content = resolveTooltip(source);
      if (!content) {
        this.hide();
        return;
      }
      anchor = position;
      element.innerHTML = renderTooltipHtml(content);
      element.style.setProperty("--maplab-tooltip-offset", `${offsetPx}px`);
      element.style.display = "";
      overlay.draw();
      requestAnimationFrame(() => element.classList.add("is-on"));
    },
    hide() {
      anchor = null;
      element.classList.remove("is-on");
      element.style.display = "none";
    },
    destroy() {
      this.hide();
      overlay.setMap(null);
    },
  };
}
