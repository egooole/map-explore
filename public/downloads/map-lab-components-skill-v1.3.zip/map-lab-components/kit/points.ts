import * as assets from "./assets";
import type { LatLng, MapLabHandle, MapLabState, MapLabTooltipSource } from "./types";

/**
 * 点组件（Advanced Marker）。
 * - normal：基础定位点，24px 圆点，hover/selected 放大到 40px
 * - informated：带业务图标的信息点（仓库等），59×62，hover/selected 95×99
 * - cluster：聚合点（Cumulative Location），显示数量，40px → 64px
 * - custom：自定义内容（warehouse / shop / user 图标，或字母、数字）
 */
export type LocationKind = "normal" | "informated" | "cluster" | "custom";
export type CustomIcon = "warehouse" | "shop" | "user" | "text";

export interface LocationOptions {
  /** 业务 ID，不传则自动生成。 */
  id?: string;
  position: LatLng;
  kind?: LocationKind;
  /** kind = "custom" 时的内容；"text" 搭配 text 使用（字母或数字，最多 2 个字符）。 */
  icon?: CustomIcon;
  text?: string;
  /** kind = "cluster" 时的数量。 */
  count?: number;
  state?: MapLabState;
  /** 无障碍名称，同时作为 Agent 定位用的标签，必填。 */
  label: string;
  tooltip?: MapLabTooltipSource;
  /** Tooltip 触发方式，默认 hover。 */
  tooltipTrigger?: "hover" | "click";
  /** 是否可点击选中，默认：default / completed / emphasized 状态可点击。 */
  interactive?: boolean;
  onClick?: (handle: LocationHandle) => void;
  zIndex?: number;
}

export interface LocationHandle extends MapLabHandle {
  readonly element: HTMLElement;
  readonly marker: google.maps.marker.AdvancedMarkerElement;
  readonly options: LocationOptions;
  setState(state: MapLabState): void;
  setSelected(selected: boolean): void;
  setPosition(position: LatLng): void;
  /** 锚点到元素顶部的像素高度，用于把 Tooltip 放在点的上方。 */
  tooltipOffset(): number;
}

const stateToVariant: Record<MapLabState, string> = {
  default: "default",
  disabled: "muted",
  completed: "completed",
  emphasized: "emphasized",
  selected: "selected",
};

const informatedByState: Record<MapLabState, string> = {
  default: assets.informatedDefault,
  disabled: assets.informatedDisabled,
  completed: assets.informatedCompleted,
  emphasized: assets.informatedEmphasized,
  selected: assets.informatedSelected,
};

const customColor: Partial<Record<MapLabState, string>> = {
  default: "#2A3EF4",
  disabled: "#C9D2FC",
  completed: "#9C9EAD",
  emphasized: "#2A3EF4",
  selected: "#2232C3",
};

export function svgDataUri(svg: string) {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function escapeText(value: string) {
  return value.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
}

function markup(kind: LocationKind, state: MapLabState, options: LocationOptions) {
  if (kind === "informated") {
    return `<span class="MapLabMarker__asset"><img alt="" class="MapLabMarker__assetBase" src="${svgDataUri(informatedByState[state])}" /><img alt="" class="MapLabMarker__assetSelected" src="${svgDataUri(assets.informatedSelected)}" /></span>`;
  }
  if (kind === "cluster") {
    return `<span class="MapLabMarker__cluster"><b>${escapeText(String(options.count ?? ""))}</b></span>`;
  }
  if (kind === "custom") {
    const icon = options.icon ?? "warehouse";
    if (icon === "text") {
      return `<span class="MapLabMarker__customTextPin"><b>${escapeText((options.text ?? "").slice(0, 2))}</b></span>`;
    }
    const raw = icon === "shop" ? assets.customShop : icon === "user" ? assets.customUser : assets.customWarehouse;
    const colored = raw.replace(/var\(--fill-0,\s*#2A3EF4\)/gi, customColor[state] ?? "#2A3EF4");
    return `<span class="MapLabMarker__customAsset"><img alt="" src="${svgDataUri(colored)}" /></span>`;
  }
  return "<span><i></i></span>";
}

function familyClass(kind: LocationKind) {
  return kind === "normal" ? "point" : kind === "cluster" ? "cumulative" : kind;
}

/** 锚点：圆形居中；Pin 形以尖端对准坐标。 */
function anchorFor(kind: LocationKind) {
  if (kind === "normal" || kind === "cluster") return { left: "-50%", top: "-50%" };
  if (kind === "informated") return { left: "-50%", top: "-51px" };
  return { left: "-50%", top: "-100%" };
}

let uid = 0;

export interface PointContext {
  map: google.maps.Map;
  onSelect(handle: LocationHandle | null): void;
  showTooltip(position: LatLng, source: MapLabTooltipSource, offsetPx: number): void;
  hideTooltip(): void;
}

export async function createLocation(ctx: PointContext, options: LocationOptions): Promise<LocationHandle> {
  const { AdvancedMarkerElement } = (await google.maps.importLibrary("marker")) as google.maps.MarkerLibrary;
  const kind = options.kind ?? "normal";
  const id = options.id ?? `maplab-location-${++uid}`;
  let state: MapLabState = options.state ?? "default";
  let selected = state === "selected";

  const element = document.createElement("div");
  element.dataset.maplabComponent = "location";
  element.dataset.maplabKind = kind;
  element.dataset.maplabId = id;
  element.setAttribute("aria-label", options.label);

  const isInteractive = () =>
    options.interactive ?? (state === "default" || state === "completed" || state === "emphasized" || state === "selected");

  const paint = () => {
    const variant = stateToVariant[state];
    element.className = `MapLabMarker MapLabMarker--${familyClass(kind)}-${variant}`;
    element.innerHTML = markup(kind, state, options);
    element.dataset.state = selected ? "selected" : state;
    const interactive = isInteractive();
    element.classList.toggle("MapLabMarker--interactive", interactive);
    element.classList.toggle("is-selected", selected);
    if (interactive) {
      element.setAttribute("role", "button");
      element.tabIndex = 0;
      element.setAttribute("aria-pressed", String(selected));
    } else {
      element.setAttribute("role", "img");
      element.removeAttribute("tabindex");
      element.removeAttribute("aria-pressed");
    }
  };
  paint();

  const anchor = anchorFor(kind);
  const marker = new AdvancedMarkerElement({
    content: element,
    gmpClickable: isInteractive(),
    map: ctx.map,
    position: options.position,
    title: options.label,
    zIndex: options.zIndex,
  });
  (marker as unknown as { anchorLeft: string; anchorTop: string }).anchorLeft = anchor.left;
  (marker as unknown as { anchorLeft: string; anchorTop: string }).anchorTop = anchor.top;

  const handle: LocationHandle = {
    id,
    element,
    marker,
    options,
    setState(next) {
      state = next;
      if (next === "selected") selected = true;
      paint();
      marker.gmpClickable = isInteractive();
    },
    setSelected(next) {
      selected = next;
      paint();
    },
    setPosition(position) {
      marker.position = position;
      options.position = position;
    },
    tooltipOffset() {
      const height = element.getBoundingClientRect().height || 24;
      if (kind === "normal" || kind === "cluster") return height / 2 + 8;
      if (kind === "informated") return 51 + 4;
      return height + 4;
    },
    remove() {
      cleanup();
      marker.map = null;
      element.remove();
    },
  };

  const showTip = () => {
    if (options.tooltip) ctx.showTooltip(options.position, options.tooltip, handle.tooltipOffset());
  };
  const onEnter = () => {
    if ((options.tooltipTrigger ?? "hover") === "hover") showTip();
  };
  const onLeave = () => {
    if ((options.tooltipTrigger ?? "hover") === "hover" && !selected) ctx.hideTooltip();
  };
  const onActivate = () => {
    if (!isInteractive()) return;
    ctx.onSelect(selected ? null : handle);
    if (options.tooltipTrigger === "click") {
      if (selected) showTip();
      else ctx.hideTooltip();
    }
    options.onClick?.(handle);
  };
  const onKey = (event: KeyboardEvent) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onActivate();
    }
    if (event.key === "Escape") ctx.onSelect(null);
  };
  const clickListener = marker.addListener("click", onActivate);
  element.addEventListener("pointerenter", onEnter);
  element.addEventListener("pointerleave", onLeave);
  element.addEventListener("focus", showTip);
  element.addEventListener("blur", onLeave);
  element.addEventListener("keydown", onKey);
  const cleanup = () => {
    clickListener.remove();
    element.removeEventListener("pointerenter", onEnter);
    element.removeEventListener("pointerleave", onLeave);
    element.removeEventListener("focus", showTip);
    element.removeEventListener("blur", onLeave);
    element.removeEventListener("keydown", onKey);
  };

  return handle;
}
