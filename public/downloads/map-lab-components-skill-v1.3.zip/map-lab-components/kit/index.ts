/**
 * Map Lab 组件包统一入口。
 *
 *   import "./map-lab-kit/map-lab.css";
 *   import { loadGoogleMaps, createMapLabMap, createMapLab } from "./map-lab-kit";
 *
 *   await loadGoogleMaps({ apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY });
 *   const map = await createMapLabMap(el, { center, zoom: 11, mapId: import.meta.env.VITE_GOOGLE_MAP_ID });
 *   const lab = createMapLab(map);
 *   await lab.addLocation({ kind: "informated", position, label: "上海仓" });
 *   lab.addRoute({ path, kind: "directional", endpoints: "informated", label: "路线 A" });
 *   await lab.addAreas({ geojson: "/geo/shanghai.json", style: (id) => ({ status: "partial" }) });
 *   lab.destroy();
 */
import { createAreas, type AreaHandle, type AreaOptions } from "./areas";
import { createLocation, type LocationHandle, type LocationOptions } from "./points";
import { createRoute, type RouteHandle, type RouteOptions } from "./routes";
import { createTooltipController } from "./tooltip";
import type { LatLng, MapLabTooltipSource } from "./types";

export * from "./types";
export * from "./loader";
export type { AreaHandle, AreaOptions, AreaStatus } from "./areas";
export type { LocationHandle, LocationOptions, LocationKind, CustomIcon } from "./points";
export type { RouteHandle, RouteOptions, RouteKind, RouteColor, RouteState } from "./routes";

export interface MapLabOptions {
  /** 选中一条路线时，其他路线变淡。默认 true。 */
  dimOtherRoutesOnSelect?: boolean;
}

export interface MapLab {
  readonly map: google.maps.Map;
  addLocation(options: LocationOptions): Promise<LocationHandle>;
  addLocations(list: LocationOptions[]): Promise<LocationHandle[]>;
  addRoute(options: RouteOptions): RouteHandle & { endpoints: Promise<LocationHandle[]> };
  addAreas(options: AreaOptions): Promise<AreaHandle>;
  showTooltip(position: LatLng, content: MapLabTooltipSource, offsetPx?: number): void;
  hideTooltip(): void;
  clearSelection(): void;
  /** 移除本组件包创建的所有点、线、面、Tooltip 和监听，不影响地图本身。 */
  destroy(): void;
}

export function createMapLab(map: google.maps.Map, options: MapLabOptions = {}): MapLab {
  const tooltip = createTooltipController(map);
  const locations = new Set<LocationHandle>();
  const routes = new Set<RouteHandle>();
  const areas = new Set<AreaHandle>();
  let selectedLocation: LocationHandle | null = null;
  let selectedRoute: RouteHandle | null = null;

  const showTooltip = (position: LatLng, source: MapLabTooltipSource, offsetPx = 8) => tooltip.show(position, source, offsetPx);
  const hideTooltip = () => tooltip.hide();

  const selectLocation = (handle: LocationHandle | null) => {
    if (selectedLocation && selectedLocation !== handle) selectedLocation.setSelected(false);
    selectedLocation = handle;
    handle?.setSelected(true);
    if (!handle) hideTooltip();
  };
  const selectRoute = (handle: RouteHandle | null) => {
    if (selectedRoute && selectedRoute !== handle) selectedRoute.setSelected(false);
    selectedRoute = handle;
    handle?.setSelected(true);
    if (options.dimOtherRoutesOnSelect !== false && routes.size > 1) {
      routes.forEach((r) => r.setDimmed(Boolean(handle) && r !== handle));
    }
  };

  // 点击地图空白处：清除选中、收起 Tooltip。
  const mapClick = map.addListener("click", () => {
    selectLocation(null);
    selectRoute(null);
    hideTooltip();
  });

  const pointCtx = { map, onSelect: selectLocation, showTooltip, hideTooltip };

  const lab: MapLab = {
    map,
    async addLocation(o) {
      const handle = await createLocation(pointCtx, o);
      locations.add(handle);
      const remove = handle.remove;
      handle.remove = () => {
        locations.delete(handle);
        if (selectedLocation === handle) selectedLocation = null;
        remove();
      };
      if (handle.element.dataset.state === "selected") selectLocation(handle);
      return handle;
    },
    addLocations(list) {
      return Promise.all(list.map((o) => lab.addLocation(o)));
    },
    addRoute(o) {
      const route = createRoute({ map, onSelect: selectRoute, showTooltip, hideTooltip }, o);
      routes.add(route);
      const endpointKind = o.endpoints ?? "none";
      const endpoints: Promise<LocationHandle[]> =
        endpointKind === "none" || o.path.length < 2
          ? Promise.resolve([])
          : Promise.all(
              [o.path[0], o.path[o.path.length - 1]].map((position, i) =>
                lab.addLocation({
                  kind: endpointKind,
                  position,
                  label: o.endpointLabels?.[i] ?? `${o.label} · ${i === 0 ? "起点" : "终点"}`,
                  interactive: false,
                  state: o.state === "disabled" ? "disabled" : o.state === "completed" ? "completed" : "default",
                  zIndex: 20,
                }),
              ),
            );
      const remove = route.remove;
      const withEndpoints = Object.assign(route, {
        endpoints,
        remove: () => {
          routes.delete(route);
          if (selectedRoute === route) selectedRoute = null;
          remove();
          void endpoints.then((list) => list.forEach((h) => h.remove()));
        },
      });
      return withEndpoints;
    },
    async addAreas(o) {
      const handle = await createAreas({ map, showTooltip, hideTooltip }, o);
      areas.add(handle);
      const remove = handle.remove;
      handle.remove = () => {
        areas.delete(handle);
        remove();
      };
      return handle;
    },
    showTooltip,
    hideTooltip,
    clearSelection() {
      selectLocation(null);
      selectRoute(null);
      areas.forEach((a) => a.select(null));
      hideTooltip();
    },
    destroy() {
      mapClick.remove();
      [...locations].forEach((h) => h.remove());
      [...routes].forEach((h) => h.remove());
      [...areas].forEach((h) => h.remove());
      tooltip.destroy();
    },
  };
  return lab;
}
