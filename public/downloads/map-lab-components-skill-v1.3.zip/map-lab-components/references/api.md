# 组件包 API

源码在 `kit/`。只调用这里列出的 API，不要修改 kit 内部文件；需要新能力时先告诉用户。

## 加载与创建

| 函数 | 说明 |
| --- | --- |
| `loadGoogleMaps({ apiKey, language?, region?, version?, preview? })` | 加载 Google Maps JS API，重复调用安全。`apiKey` 为空时进入预览模式（`preview: false` 可关闭）。已有 loader 的项目不用调用。 |
| `isPreviewMode()` | 当前是否是预览模式。只在需要绕开 Directions / Places 等真实服务时使用。 |
| `createMapLabMap(element, { mapId?, center, zoom, ...MapOptions })` | 创建地图。`mapId` 为空时用 `DEMO_MAP_ID`。默认关闭 POI 点击、隐藏默认控件只留缩放。 |
| `createMapLab(map, { dimOtherRoutesOnSelect? })` | 在已有地图上启用组件包，返回 `lab`。一张地图只调用一次。 |
| `useMapLab(options)`（`kit/react.ts`） | React hook，返回 `{ ref, lab, map, error }`，卸载时自动 destroy。 |

已有 `google.maps.Map` 实例的项目：直接 `createMapLab(existingMap)`，但这张地图必须有 Map ID（Advanced Marker 的要求）。

## `lab` 对象

| 方法 | 返回 | 说明 |
| --- | --- | --- |
| `addLocation(LocationOptions)` | `Promise<LocationHandle>` | 加一个点 |
| `addLocations(LocationOptions[])` | `Promise<LocationHandle[]>` | 批量加点 |
| `addRoute(RouteOptions)` | `RouteHandle & { endpoints: Promise<LocationHandle[]> }` | 加一条路线（同步返回） |
| `addAreas(AreaOptions)` | `Promise<AreaHandle>` | 加一组区域（GeoJSON） |
| `showTooltip(position, content, offsetPx?)` / `hideTooltip()` | | 手动显示 / 隐藏 Tooltip，全图同时只有一个 |
| `clearSelection()` | | 取消所有选中 |
| `destroy()` | | 移除组件包画的所有东西，地图本身保留 |

内置交互：点和路线各自单选；点击地图空白处清除选中并收起 Tooltip；有多条路线时选中一条其他变淡。

## LocationOptions（点）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `position` | `{ lat, lng }` | 必填 |
| `label` | `string` | 必填。无障碍名称，也是 Agent 定位用的文字 |
| `kind` | `"normal" \| "informated" \| "cluster" \| "custom"` | 默认 normal |
| `state` | `"default" \| "disabled" \| "completed" \| "emphasized" \| "selected"` | 默认 default |
| `count` | `number` | cluster 显示的数量 |
| `icon` / `text` | `"warehouse" \| "shop" \| "user" \| "text"` / 最多 2 个字符 | custom 的内容 |
| `tooltip` | `MapLabTooltipContent \| () => MapLabTooltipContent \| null` | 默认悬停显示 |
| `tooltipTrigger` | `"hover" \| "click"` | |
| `interactive` | `boolean` | 默认 default / completed / emphasized 可点 |
| `onClick` | `(handle) => void` | |
| `id`, `zIndex` | | |

`LocationHandle`：`setState`、`setSelected`、`setPosition`（实时移动）、`remove`，以及 `element`、`marker`。

## RouteOptions（线）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `path` | `{ lat, lng }[]` | 必填，至少 2 个点 |
| `label` | `string` | 必填 |
| `kind` | `"normal" \| "directional" \| "progress"` | 无箭头 / 有箭头 / 带进度，默认 normal |
| `color` | `"route1" \| "route2" \| "route3"` | 蓝 / 青绿 / 紫，默认 route1 |
| `state` | `"default" \| "disabled" \| "completed"` | |
| `progress` | `0–1` | progress 路线的完成比例 |
| `endpoints` | `"none" \| "normal" \| "informated"` | 起终点用哪种点，默认 none |
| `endpointLabels` | `[起点, 终点]` | |
| `tooltip` | Tooltip 内容 | 悬停路线时跟随指针 |
| `progressTooltip` | Tooltip 内容 | 点击进度点时显示 |
| `onClick`, `onHoverChange` | | |

`RouteHandle`：`setSelected`、`setDimmed`、`setProgress`、`setState`、`progressPosition()`、`remove`。

## AreaOptions（面）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `geojson` | FeatureCollection 对象或 URL | 必填，真实边界 |
| `idProperty` / `nameProperty` | `string` | 默认 `id` / `name` |
| `style` | `(id, feature) => { status?, color?, disabled? }` | `status`: full / partial / none；`color`: 自定义单色；都不传用默认蓝色 |
| `tooltip` | `(id, feature) => MapLabTooltipContent \| null` | 悬停显示在区域中心；`title` 留空自动用区域名 |
| `clickable` | `(id, feature) => boolean` | 默认 none 和 disabled 不可点 |
| `onClick` | `(id, feature) => void` | |
| `fitBounds` | `boolean` | 默认 true，加载后缩放到全部区域 |

`AreaHandle`：`select(id|null)`、`focus(ids|null)`、`flash(id)`、`fitTo(id)`、`centerOf(id)`、`refresh()`、`remove`、`layer`。

## Tooltip 内容

```ts
{
  title: "上海一号仓",
  tag: { text: "运营中", tone: "success" },   // tone: info | success | neutral | warning
  rows: [["今日单量", "1,204"], ["覆盖", "12 个区"]],
  hint: "点击查看详情",
}
```

只能用这四个字段。不要往 Tooltip 里塞按钮、图片或自定义 HTML；需要操作区时放到地图外的侧边面板。

## 给 Agent 和测试用的 DOM 标记

| 选择器 | 含义 |
| --- | --- |
| `[data-maplab-component="location"]` | 点；`data-maplab-kind`、`data-maplab-id`、`data-state` |
| `[data-maplab-component="route"]` | 路线容器；`data-state` 为 default / hover / selected / disabled / completed |
| `[data-maplab-component="progress-location"]` | 进度点按钮 |
| `[data-maplab-component="tooltip"]` | Tooltip；显示时带 `is-on` 类 |

点是 `role="button"` + `aria-pressed`，支持 Tab 聚焦、Enter / 空格选中、Esc 取消。
