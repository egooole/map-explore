# API Key、Map ID 和底图样式

## 需要准备什么

| 配置 | 必须？ | 放在哪里 |
| --- | --- | --- |
| Google Maps API Key | 看真实地图时需要；没有时进入预览模式 | `.env.local` 的 `VITE_GOOGLE_MAPS_API_KEY`（Next.js 用 `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`） |
| Map ID | 可选 | `VITE_GOOGLE_MAP_ID`（Next.js 用 `NEXT_PUBLIC_GOOGLE_MAP_ID`） |

- Key 只能从环境变量读取，**绝不写进代码、文档、截图或提交记录**。把 `.env.local` 加进 `.gitignore`，并提供一个不含真实值的 `.env.example`。
- 用户想看真实地图但还没有 Key 时，告诉他：在 Google Cloud Console 新建项目 → 启用 Maps JavaScript API → 凭据里创建 API Key → 在「应用限制」里填本地和线上的网址（如 `http://localhost:5173/*`）。不要替用户编造或去别处找 Key。

## 三种状态

| 配置 | 看到的效果 |
| --- | --- |
| 没有 Key | **预览模式**：浅色网格底图，Map Lab 组件和交互完整，左下角提示「预览模式」 |
| 有 Key，没有 Map ID | 真实 Google 地图（默认底图）+ Map Lab 组件 |
| 有 Key + 自己的 Map ID | 真实 Google 地图 + Map Lab 底图 + Map Lab 组件 |

三种状态用的是同一份代码，切换只需要改 `.env.local` 并重启开发服务器。

## 没有 Key：预览模式

`loadGoogleMaps` 发现 Key 为空时，会安装一个轻量的替身地图（`kit/preview.ts`），然后正常返回。之后的 `createMapLabMap`、`createMapLab` 和所有组件 API 都照常使用。

- 支持拖动、滚轮缩放、缩放按钮、`fitBounds`、`setCenter`、`setZoom`、`getZoom`、地图 `click` / `idle` 事件。
- 没有道路、地名、POI、卫星图，也不支持 `google.maps` 里组件包没用到的其他功能（如 Directions、Places、Geocoder）。业务代码用到这些服务时，要判断 `isPreviewMode()`，在预览模式下改用本地示例数据。
- 想在缺 Key 时直接报错而不是预览：`loadGoogleMaps({ apiKey, preview: false })`。

## 没有 Map ID：DEMO_MAP_ID

`createMapLabMap` 在没有 Map ID 时自动用 Google 提供的 `DEMO_MAP_ID`：

- 所有人都能用，不需要申请。
- 点、线、面、Tooltip 的 Map Lab 样式完全正确（这些都是组件包自己画的）。
- 底图是 Google 默认样式，不是 Map Lab 的浅色底图。
- 适合原型和 vibe coding；正式上线前建议换成自己的 Map ID。

向用户说明时用一句话即可：「现在用的是 Google 演示用的 Map ID，组件样式是对的，底图是默认样式；想要 Map Lab 底图可以按下面步骤配置自己的 Map ID。」

## 配置 Map Lab 底图（自己的 Map ID）

底图样式绑定在 Map ID 上，只能在 Google Cloud Console 里配置，代码里无法复制。

1. Google Cloud Console → Google Maps Platform → **Map Management（地图管理）** → Create Map ID：类型选 JavaScript，渲染选 **Vector**。
2. 进入 **Map Styles（地图样式）** → 新建样式。
3. 导入 Map Lab 样式文件 `basemap/map-lab-style.json`（如果 skill 里没有这个文件，说明作者还没导出，先跳过这一步，使用默认样式）。如果编辑器版本不支持导入 JSON，就按 Map Lab 截图手动调整：浅灰底、弱化 POI 和道路标注。
4. 保存并发布样式，把它关联到第 1 步的 Map ID。
5. 把 Map ID 填到 `VITE_GOOGLE_MAP_ID`，重启开发服务器。

注意：用了 Map ID 后，不要再给地图传 `styles` 参数，两者会冲突。

## 团队共享 Key（可选）

如果团队想共用一个 Key 和 Map ID，由负责人通过内部渠道（如密码管理器）分发，并在 Cloud Console 里限制可用的网址和 API。不要把共享 Key 写进这个 skill。
