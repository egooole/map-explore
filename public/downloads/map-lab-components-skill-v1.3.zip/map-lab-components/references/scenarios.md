# 场景 → 组件对照表

先从这张表找到最接近的场景，照抄对应的写法，再替换成用户的业务数据。
所有写法都假设已经有 `lab`（见 SKILL.md 第 3 步）。坐标、名称、数值都是示例。

| 用户说的场景（中 / 英） | 用哪些组件 | 写法 |
| --- | --- | --- |
| 仓库 / 网点 / 门店分布，site map, warehouse locations | Informated 点 + Tooltip | [A](#a-网点分布) |
| 大量点、缩小后要聚合，clustering | Cluster 点 + Normal 点 | [B](#b-聚合点) |
| 配送路线、干线、A 到 B，delivery route | 有向路线 + informated 起终点 | [C](#c-配送路线) |
| 司机 / 车辆实时位置、送货进度，driver tracking | Progress 路线 + 进度点 Tooltip | [D](#d-司机进度) |
| 多条路线比较、方案对比，compare routes | route1 / route2 / route3，选中其他变淡 | [E](#e-多路线对比) |
| 覆盖范围、服务区、配送区，coverage, service area | Areas（status 三档）+ Tooltip + 下钻 | [F](#f-覆盖范围) |
| 某个设施覆盖了哪些区 | Areas.focus + Informated 点 | [G](#g-设施覆盖了哪些区) |
| 区域选择、选区，pick a region | Areas（默认蓝色样式）+ select | [H](#h-区域选择) |
| 用户 / 骑手 / 客户位置，带字母编号的点 | Custom 点（user / shop / text） | [I](#i-自定义点) |

找不到对应场景时，用最接近的组合拼出来，不要新造视觉样式。

## A. 网点分布

```ts
const sites = await lab.addLocations(
  data.map((s) => ({
    id: s.id,
    kind: "informated",
    position: { lat: s.lat, lng: s.lng },
    label: s.name,
    state: s.active ? "default" : "disabled",
    tooltip: {
      title: s.name,
      tag: { text: s.active ? "运营中" : "已停用", tone: s.active ? "success" : "neutral" },
      rows: [["今日单量", s.orders.toLocaleString()], ["覆盖", `${s.areas} 个区`]],
    },
    onClick: (h) => openDetail(h.id),
  })),
);
```

## B. 聚合点

组件包不自带聚合算法。按缩放级别自己分组（或用 `@googlemaps/markerclusterer` 只做分组计算），每组用 `kind: "cluster"` 画；放大后换成 Normal 点。

```ts
let handles: Array<{ remove(): void }> = [];
async function render() {
  handles.forEach((h) => h.remove());
  const groups = groupByGrid(points, lab.map.getZoom() ?? 10); // 业务自己的分组
  handles = await lab.addLocations(
    groups.map((g) =>
      g.items.length > 1
        ? { kind: "cluster", count: g.items.length, position: g.center, label: `${g.items.length} 个点`,
            onClick: () => { lab.map.setCenter(g.center); lab.map.setZoom((lab.map.getZoom() ?? 10) + 2); } }
        : { kind: "normal", position: g.items[0].position, label: g.items[0].name },
    ),
  );
}
lab.map.addListener("idle", render);
```

## C. 配送路线

```ts
const route = lab.addRoute({
  kind: "directional",
  path: routeResult.path,             // 用户已有的路线坐标，不要改写
  endpoints: "informated",
  endpointLabels: ["上海一号仓", "浦东配送站"],
  label: "干线 A",
  tooltip: { title: "干线 A", rows: [["距离", "32.4 km"], ["预计", "48 分钟"]] },
});
```

只要线、不要箭头：`kind: "normal"`。起终点用普通圆点：`endpoints: "normal"`。

## D. 司机进度

```ts
const trip = lab.addRoute({
  kind: "progress",
  color: "route1",
  path,
  progress: 0.42,
  endpoints: "informated",
  label: "司机 王师傅",
  progressTooltip: () => ({
    title: "王师傅 · 沪A12345",
    tag: { text: "配送中", tone: "info" },
    rows: [["已完成", "42%"], ["剩余", "6 单"]],
  }),
});
// 实时更新
socket.on("progress", (p) => trip.setProgress(p));
```

## E. 多路线对比

```ts
const colors = ["route1", "route2", "route3"] as const;
plans.slice(0, 3).forEach((plan, i) =>
  lab.addRoute({ kind: "directional", color: colors[i], path: plan.path, label: plan.name,
                 tooltip: { title: plan.name, rows: [["时长", plan.duration], ["成本", plan.cost]] } }),
);
// 点击某条路线会自动选中它，其他路线变淡；点地图空白处恢复。
```

超过 3 条时，只给最重要的 3 条上色，其余用 `state: "disabled"`。

## F. 覆盖范围

覆盖状态固定三档：`full`（完全覆盖，#009995）、`partial`（部分覆盖，#2A3EF4）、`none`（未覆盖，#616B94）。左上角放图例时用同样三种颜色。

```ts
const areas = await lab.addAreas({
  geojson: "/geo/shanghai-districts.json",  // 真实行政区 GeoJSON，不要用矩形代替
  idProperty: "adcode",
  nameProperty: "name",
  style: (id) => ({ status: coverage[id]?.status ?? "none" }),
  tooltip: (id) => {
    const c = coverage[id];
    if (!c) return null;
    return {
      title: "",                         // 留空会自动用区域名称
      tag: { text: c.status === "full" ? "完全覆盖" : c.status === "partial" ? "部分覆盖" : "未覆盖",
             tone: c.status === "full" ? "success" : c.status === "partial" ? "info" : "neutral" },
      rows: [["覆盖率", `${c.rate}%`], ["设施", `${c.sites} 个`]],
      hint: c.status === "none" ? undefined : "点击查看下一级",
    };
  },
  onClick: (id) => drillDown(id),          // 未覆盖区域默认不可点击
});
```

下钻：`areas.remove()` 后用下一级 GeoJSON 再 `addAreas`，并 `areas.fitTo(id)` 或让新图层自动 fitBounds。

## G. 设施覆盖了哪些区

```ts
const site = await lab.addLocation({
  kind: "informated", position: s.position, label: s.name,
  onClick: () => {
    areas.focus(s.coveredAreaIds);       // 其他区域变淡
    areas.fitTo(s.coveredAreaIds[0]);
  },
});
// 点空白处恢复：
lab.map.addListener("click", () => areas.focus(null));
```

## H. 区域选择

```ts
const areas = await lab.addAreas({
  geojson,
  onClick: (id) => { areas.select(id); onPick(id); },
});
```

不传 `style` 时就是 Map Lab 默认区域样式（蓝色 10% 填充，悬停 / 选中 40%）。

## I. 自定义点

```ts
await lab.addLocation({ kind: "custom", icon: "user", position, label: "客户 张三" });
await lab.addLocation({ kind: "custom", icon: "shop", position, label: "门店" });
await lab.addLocation({ kind: "custom", icon: "text", text: "A", position, label: "站点 A" });
```

`icon` 只有 `warehouse`、`shop`、`user`、`text` 四种。需要别的图标时告诉用户目前组件库没有，先用 `text` 或 Informated 点代替。
