# Component Catalog

Use this catalog to map a Map Lab design term to the kit API (`kind` values in parentheses).

## Point Components

| Component | Purpose | Primitive | Anchor |
| --- | --- | --- | --- |
| Normal (`normal`) | Generic location, POI, waypoint | Advanced Marker + circular DOM | center |
| Informated Location (`informated`) | Business entity such as warehouse or site | Advanced Marker + exact SVG | bottom or pin-tip |
| Cumulative Location (`cluster`) | Cluster count that expands into leaf points | Advanced Marker + cluster DOM | center |
| Custom (`custom`) | Letter, number, warehouse, shop, or user content | Advanced Marker + SVG/DOM slot | bottom |

Point states are `default`, `disabled` (Disable; CSS class suffix `muted`), `completed`, `emphasized`, and `selected`. Product UIs may expose only Default, Disable, and Completed in their state switcher.

## Line Components

| Component | Composition |
| --- | --- |
| Normal route / No arrow (`kind: "normal"`) | White outline polyline + colored body polyline |
| Normal route / Has arrow (`kind: "directional"`) | Normal route + repeating directional arrow overlay |
| Route with normal location (`endpoints: "normal"`) | Has-arrow route + Normal points at both ends |
| Route with informated location (`endpoints: "informated"`) | Has-arrow route + Informated Location pins at both ends |
| Route with progress (`kind: "progress"`) | Remaining default route + completed route segment + progress pin |

The route body is an `OverlayView` SVG, never an Advanced Marker. Endpoints are Advanced Markers; the progress pin is part of the route overlay.

## Area Components

| Component | Composition |
| --- | --- |
| Area selection (`addAreas`) | `google.maps.Data` polygon + optional Advanced Marker center label |

Use real GeoJSON geometry. Do not represent an administrative region with a rounded rectangle or bounding box.

## Container And Visualization Components

The current Map Lab catalog does not yet define production-ready container or visualization-map components. Do not invent component names or styles. Ask for the missing design source, or clearly mark a placeholder as provisional.

## Composition Rule

Build combined components from existing primitives. For example, Route with informated location reuses the route family and swaps only the endpoint component. Keep route state, pin state, and business interaction as separate inputs so one can change without corrupting the other.
