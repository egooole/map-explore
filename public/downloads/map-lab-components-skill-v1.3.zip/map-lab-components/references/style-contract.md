# Style Contract

这些数值已经写在 `kit/` 里，正常使用组件包时不需要手动设置。本文件用于核对视觉、回答设计问题，或给地图外的 UI（图例、侧边栏）取色。

## Shared Colors

| Meaning | Value |
| --- | --- |
| Primary / Default | `#2A3EF4` |
| Primary focused | `#2232C3` |
| Disable | `#C9D2FC` |
| Completed | `#9C9EAD` |
| White outline | `#FFFFFF` |

Keep raw values until Map Lab Code Tokens are supplied. When the target product has an approved token mapping, replace values centrally rather than per component.

## Point Dimensions

- Normal: 24px overall in default/muted/completed; 40px overall in emphasized/hover/selected.
- Informated Location: preserve the supplied SVG frame, 59x62 default and 95x99 emphasized/hover/selected.
- Cumulative Location: 40px default; 64px hover/selected.
- Custom image pin: preserve its SVG viewBox and visual frame.

The stated dimension is the full component box, including its white border where applicable, not only the colored center.

## Route Dimensions

- Static route: white outline 12px, colored body 8px.
- Hover/selected route: white outline 16px, colored body 12px.
- Outline remains 2px visible on each side.
- Directional arrow spacing is measured head-to-head in screen pixels.
- Map Lab arrow spacing (kit default): first arrow 22px from the start, then every 28px head-to-head. Arrow scale 7.83/20 (static) and 12.36/20 (hover/selected).

Dynamic route palette:

| Route | Default | Hover/Selected |
| --- | --- | --- |
| 1 | `#2A3EF4` | `#2232C3` |
| 2 | `#009995` | `#017B77` |
| 3 | `#9583FF` | `#8575FF` |

Directional arrow state colors for the primary route:

| State | Arrow |
| --- | --- |
| Default | `#768BFF` |
| Disable | `#D9E0FD` |
| Completed | `#C4C5CE` |

## Region Styles

| State | Fill | Opacity | Stroke | Weight |
| --- | --- | --- | --- | --- |
| Default | `#2A3EF4` | 0.10 | `#2A3EF4` | 2px |
| Disable | `#2A3EF4` | 0.06 | `#C9D2FC` | 2px |
| Hover/Selected | `#2A3EF4` | 0.40 | `#2A3EF4` | 2px |

Ignore rounded-corner values from Figma state swatches. Geographic polygons have no corner radius.

## Coverage Status (Areas)

| Status | Color | Fill opacity | Hover |
| --- | --- | --- | --- |
| Fully covered (`full`) | `#009995` | 0.26 | +0.16, stroke `#171718` 2px |
| Partially covered (`partial`) | `#2A3EF4` | 0.26 | +0.16, stroke `#171718` 2px |
| Not covered (`none`) | `#616B94` | 0.22 | not clickable |

Default stroke is white 1px. Areas outside `focus()` drop to 35% opacity. Use the same three colors in any legend.

## Tooltip

- Background `rgba(255,255,255,.95)`, radius 4px, padding 8px 12px, shadow `0 8px 20px rgba(0,0,0,.12)`, min width 200px.
- Text 12px / 18px. Title `#171718` 500. Row label column 54px `#6C6D6F`; value right-aligned `#171718` 500.
- 14×5 arrow under the box. One tooltip per map.
- Tag: 20px high, radius 4px. info `rgba(42,62,244,.1)` / `#2A3EF4`; success `rgba(0,153,149,.1)` / `#007A77`; neutral `rgba(97,107,148,.12)` / `#4C5476`; warning `rgba(232,119,26,.12)` / `#B9520A`.

## Motion

- Point size transitions: 120-200ms ease.
- Progress pin body hover scale: CSS variable `--pin-hover-scale: 1.6`.
- Progress pulse: 1.5s ease-out infinite, opacity 0.3 to 0.1, transform-only scale animation.
- Keep pulse animation independent from hover so hover does not restart it.

## Layering

Place route endpoint pins and progress pins above route bodies and arrows. Keep white outlines under colored route bodies. Ensure overlays use `pointer-events` intentionally so the route remains hoverable without the pins stealing input.
