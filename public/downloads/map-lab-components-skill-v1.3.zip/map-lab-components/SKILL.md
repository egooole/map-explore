---
name: map-lab-components
description: Map Lab 地图组件包（Google Maps）。只要用户要在网页或应用里做任何地图相关的东西，就使用这个 skill，用 Map Lab 的点、线、面、Tooltip 作为视觉和交互样式，即使用户没提 Map Lab。触发场景包括：画地图、地图上标点、仓库/网点/门店分布、配送路线、司机或车辆追踪、送货进度、多路线对比、覆盖范围、服务区、区域选择、行政区高亮、地图弹窗；英文如 map, markers, pins, route, delivery tracking, coverage map, service area, geofence, Google Maps, AdvancedMarkerElement。
---

# Map Lab Components

`kit/` 是一个现成的 Google Maps 组件包：点（Normal / Informated / Cluster / Custom）、线（无箭头 / 有箭头 / 带进度，可带起终点）、面（覆盖状态 / 区域选择）和统一的 Tooltip，交互和样式都已内置。
做地图功能时，**直接调用组件包**，不要自己画 Marker、SVG 或另配颜色。

## 工作流程

### 1. 把组件包放进项目

把本 skill 的 `kit/` 整个复制到项目里（如 `src/map-lab-kit/`），不要改里面的文件。

- 不依赖 React 和打包器配置，TypeScript / JavaScript 项目都能直接 import。
- 非 React 项目不要复制 `kit/react.ts`。
- 安装类型（TypeScript 项目）：`npm i -D @types/google.maps`，并在 tsconfig 的 `types` 里加 `"google.maps"`。
- 引入一次样式：`import "./map-lab-kit/map-lab.css";`

### 2. 配置 Key 和 Map ID

读 [references/basemap.md](references/basemap.md)。要点：

- Key 只从环境变量读（Vite：`VITE_GOOGLE_MAPS_API_KEY`），绝不写进代码，也不要向用户索要 Key。
- **没有 Key 也照常写完整功能。** 组件包会自动进入预览模式：浅色网格底图 + 完整的 Map Lab 点、线、面、Tooltip 和交互，可以拖动缩放。不要做「请先连接 Google Maps」之类的占位页面，也不要因为缺 Key 跳过地图渲染。完成后用一句话告诉用户：现在是预览模式，填上 Key 并重启开发服务器后会自动显示真实地图。
- Map ID 可选：有 Key 没有 Map ID 时自动用 `DEMO_MAP_ID`，组件样式正确、底图为 Google 默认样式；配置自己的 Map ID 可以换成 Map Lab 底图。
- 生成 `.env.example`（只写变量名），确认 `.env.local` 在 `.gitignore` 里。

### 3. 创建地图和 `lab`

原生 TS / JS：

```ts
import "./map-lab-kit/map-lab.css";
import { loadGoogleMaps, createMapLabMap, createMapLab } from "./map-lab-kit";

await loadGoogleMaps({ apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY });
const map = await createMapLabMap(document.getElementById("map")!, {
  mapId: import.meta.env.VITE_GOOGLE_MAP_ID,
  center: { lat: 31.23, lng: 121.47 },
  zoom: 11,
});
const lab = createMapLab(map);
```

React：

```tsx
import "./map-lab-kit/map-lab.css";
import { useMapLab } from "./map-lab-kit/react";

const { ref, lab, error } = useMapLab({ apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
  mapId: import.meta.env.VITE_GOOGLE_MAP_ID, center: { lat: 31.23, lng: 121.47 }, zoom: 11 });
useEffect(() => {
  if (!lab) return;
  const handles: Array<{ remove(): void }> = [];
  lab.addLocations(sites).then((hs) => handles.push(...hs));
  return () => handles.forEach((h) => h.remove());
}, [lab, sites]);
return <div ref={ref} style={{ width: "100%", height: 520 }} />;
```

项目里已经有 `google.maps.Map`：保留原来的 loader 和地图，直接 `createMapLab(existingMap)`。这张地图需要有 Map ID（没有就加 `mapId: "DEMO_MAP_ID"`）。

地图容器必须有明确高度。

### 4. 按场景选组件

打开 [references/scenarios.md](references/scenarios.md)，找到最接近的场景，照抄写法，换成用户的数据。完整参数见 [references/api.md](references/api.md)。

| 用户要的 | 用 |
| --- | --- |
| 地点、仓库、网点 | `lab.addLocation({ kind: "informated" \| "normal", ... })` |
| 很多点要聚合 | `kind: "cluster"` |
| 路线、A 到 B | `lab.addRoute({ kind: "directional", endpoints: "informated", ... })` |
| 司机 / 车辆进度 | `lab.addRoute({ kind: "progress", progress, progressTooltip })` |
| 多条路线比较 | `color: "route1" \| "route2" \| "route3"` |
| 覆盖范围、服务区、行政区 | `lab.addAreas({ geojson, style: () => ({ status }) , tooltip })` |
| 地图上的信息弹窗 | 各组件的 `tooltip` 参数，或 `lab.showTooltip` |

### 5. 检查

- 跑项目的构建或类型检查。
- 有浏览器工具时，打开页面确认：点和线显示正确、悬停出 Tooltip、点击选中、点空白处取消；控制台没有报错。
- 组件卸载或数据变化时调用 handle 的 `remove()`（或 `lab.destroy()`），不要重复叠加。
- 没有 Key 时在预览模式下检查同样有效；告诉用户底图要等填上 Key 才会变成真实地图。

## 硬规则

- 点、线、面、地图弹窗一律用组件包。不要用 `google.maps.Marker`、默认红色 Pin、`InfoWindow`、自己写的 SVG / Canvas 路线，也不要引入别的地图组件库来画这些。
- 不要自定义组件颜色、尺寸或图标。颜色只能用组件包的状态、`route1–3` 和覆盖三档；地图外的 UI（图例、侧栏）需要配色时从 [references/style-contract.md](references/style-contract.md) 取。
- 每个点和路线都要给 `label`（无障碍名称，也方便 Agent 和测试定位）。
- 面必须用真实 GeoJSON 边界，不要用矩形或圆形代替行政区。
- 不要改用户的坐标、路线结果和业务数据。
- 一张地图只调用一次 `createMapLab`，不要为切换状态重建地图。
- 不要自己判断「有没有 Key」去切换不同的界面；交给 `loadGoogleMaps`，它会自动选择真实地图或预览模式。
- 用了 Map ID 就不要再传 `styles`。
- 组件包没有的能力（新图标、热力图、等时圈等），告诉用户目前没有对应组件，用最接近的组件代替并说明，不要自造样式。

## 参考文件

- [references/scenarios.md](references/scenarios.md)：场景 → 组件对照和可复制的写法
- [references/api.md](references/api.md)：全部参数、handle 方法、DOM 标记
- [references/basemap.md](references/basemap.md)：Key、预览模式、Map ID、DEMO_MAP_ID、底图样式
- [references/component-catalog.md](references/component-catalog.md)：Map Lab 设计稿组件名 ↔ 组件包参数
- [references/style-contract.md](references/style-contract.md)：颜色、尺寸、动效数值
